Brad Earnhardt — Portfolio Export
========================================

This is a static HTML + CSS export of brad.fernando-vargas.com.
No JavaScript is required — all pages are self-contained HTML.

File structure:
  index.html              — Home page
  work.html               — Work / case studies listing
  work/rothman-mobile.html
  work/safensound.html
  work/ri-analytics-dashboard.html
  process.html            — Design process
  about.html              — About + resume
  contact.html            — Contact info
  assets/styles.css       — All styles
  edits.json              — Text overrides (if any edits were made)

To host: upload all files to any static web host (Netlify, Vercel,
GitHub Pages, S3, etc.) preserving the folder structure.

Images reference absolute URLs (Unsplash). If hosting offline,
download images and update src attributes in the HTML files.

Exported: 2026-04-22T16:37:47.720Z